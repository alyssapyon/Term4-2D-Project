package com.example.code2d;

public class MyClass {
}
